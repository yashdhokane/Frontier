@extends('home')
@section('content')

	<form method="POST" action="{{route('users.update', $user->id) }}"  enctype="multipart/form-data">
            @csrf
            @method('PUT')	
 <!-- End Left Sidebar - style you can find in sidebar.scss  -->
      <!-- -------------------------------------------------------------- -->
      <!-- -------------------------------------------------------------- -->
      <!-- Page wrapper  -->
      <!-- -------------------------------------------------------------- -->
      <div class="page-wrapper" style="display:inline;">
        <!-- -------------------------------------------------------------- -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- -------------------------------------------------------------- -->
        <div class="page-breadcrumb">
          <div class="row">
            <div class="col-5 align-self-center">
              <h4 class="page-title">UPDATE CUSTOMER</h4>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="customer-list.html">Customers</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Update Details</li>
                  </ol>
                </nav>
              </div>
            </div>
            <div class="col-7 align-self-center">
              <div class="d-flex no-block justify-content-end align-items-center">
                <div class="me-2">
                  <div class="lastmonth"></div>
                </div>
                <div class="">
                  <small>LAST MONTH</small>
                  <h4 class="text-info mb-0 font-medium">$58,256</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- -------------------------------------------------------------- -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- -------------------------------------------------------------- -->
        <style>
        .custom-alert {
    width: 98%; /* Adjust the width as needed */
    margin: 0 auto; /* Center the alert horizontally */
}
        </style>
		<div class="custom-alert">
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
</div>


</div>
@if(Session::has('success'))
    <div class="alert alert-success">
        {{ Session::get('success') }}
    </div>
@endif		<!-- Container fluid  -->
        <!-- -------------------------------------------------------------- -->
        <div class="container-fluid">
          <!-- -------------------------------------------------------------- -->
          <!-- Start Page Content -->
          <!-- -------------------------------------------------------------- -->
		   
 				
			<!-- row -->

			<div class="row">
			
				<div class="col-lg-6 d-flex align-items-stretch">
 					<div class="card w-100">
      								
		  					<div class="card-body border-top">
							<h4 class="card-title">Contact Info</h4>
							<div class="row">
								<div class="col-sm-12 col-md-6">
								<div class="mb-3"> 
								<label for="first_name" class="control-label col-form-label" >First Name</label >
                                <input type="text" class="form-control" id="first_name" name="first_name" value="{{ old('first_name', $first_name) }}" placeholder="" required/>              
              	</div>
								</div>
								<div class="col-sm-12 col-md-6">
								<div class="mb-3">
								<label for="last_name" class="control-label col-form-label" >Last Name</label >
								<input type="text" class="form-control" id="last_name" name="last_name" value="{{ old('last_name', $last_name) }}" placeholder=""/>
								</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
									<label for="display_name" class="control-label col-form-label" >Display Name (shown on invoice)</label >
									<input type="text" class="form-control" id="display_name" name="display_name" value="{{old('display_name', $user->name )}}" placeholder="" required/>
									</div>
								</div>
 							</div>
							<div class="row">
								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
									<label for="email" class="control-label col-form-label" >Email</label >
									<input type="email" class="form-control" id="email" name="email" value="{{old('email', $user->email )}}" placeholder="" required/>
									</div>
								</div>
 							</div>
						<div class="row">
    						<div class="col-sm-12 col-md-12">
      						  <div class="mb-3">
        					      <label for="image" class="control-label col-form-label">Image Upload</label>
         					       <input type="file" class="form-control" id="image" name="image" value="{{old('user_image', $user->image )}}" accept="image/*"/>
   	     					  </div>
   							</div>
							</div>
						</div>
					
					</div>
				</div>
				
				<div class="col-lg-3 d-flex align-items-stretch">
 					<div class="card w-100">
						<div class="card-body border-top">
							<h4 class="card-title mb-3">&nbsp;</h4>
							<div class="row">
 								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="mobile_phone" class="control-label col-form-label" >Mobile Phone</label >
										<input type="text" class="form-control" id="mobile_phone" name="mobile_phone" value="{{old('mobile_phone', $user->mobile )}}" placeholder="" required/>
									</div>
								</div>
							</div>
							<div class="row">
 								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="home_phone" class="control-label col-form-label" >Home Phone</label >
										<input type="text" class="form-control" id="home_phone" name="home_phone" placeholder="" value="{{ old('home_phone', $home_phone) }}" />
									</div>
								</div>
							</div>
							<div class="row">
 								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="work_phone" class="control-label col-form-label" >Work Phone</label >
										<input type="text" class="form-control" id="work_phone" name="work_phone" value="{{ old('work_phone', $work_phone) }}" placeholder="" />
									</div>
								</div>
							</div>
						</div>
					</div>
 				</div>
				
				<div class="col-lg-3 d-flex align-items-stretch">
 					<div class="card w-100">
						<div class="card-body border-top">
							<h4 class="card-title mb-3">&nbsp;</h4>
							<div class="row">
								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="company" class="control-label col-form-label" >Company</label >
										<input type="text" class="form-control" id="company" name="company" value="{{ old('company', $user->company) }}" placeholder="" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="role" class="control-label col-form-label" >Role</label >
										<input type="text" class="form-control" id="role" name="role" value="{{ old('role', $user->position) }}" placeholder="" />
									</div>
								</div>
							</div>
							<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="mb-3">
            <label for="inputcontact" class="control-label col-form-label">Type</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="user_type" id="exampleRadios1" value="Homeowner" {{ ($user->user_type ?? null) == 'Homeowner' ? 'checked' : '' }}>
                <label class="form-check-label" for="exampleRadios1">Homeowner</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="user_type" id="exampleRadios2" value="Business" {{ ($user->user_type ?? null) == 'Business' ? 'checked' : '' }}>
                <label class="form-check-label" for="exampleRadios2">Business</label>
            </div>
        </div>
    </div>
</div>
						</div>
					</div>
 				</div>
			
          </div>
          <!-- End row -->
		  
		  
		<!-- row -->
		<div class="row">
		
			<div class="col-lg-9 d-flex align-items-stretch">
				<div class="card w-100">
			
					<div class="card-body border-top">
						<h4 class="card-title">Address</h4>
						<div class="row">
							<div class="col-sm-12 col-md-9">
							<div class="mb-3">
							<label for="address1" class="control-label col-form-label" >Address Line 1 (Street)</label >
							<input type="text" class="form-control" id="address1" name="address1" value="{{ old('address1', $location->address_line1 ?? null) }}" placeholder="" required/>
							</div>
							</div>
							<div class="col-sm-12 col-md-3">
							<div class="mb-3">
							<label for="address_unit" class="control-label col-form-label" >Unit</label >
							<input type="text" class="form-control" id="address_unit" name="address_unit" value="{{ old('address_unit', $location->address_line2 ?? null) }}" placeholder="" />
							</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12 col-md-4">
								<div class="mb-3">
								<label for="city" class="control-label col-form-label" >City</label >
								<input type="text" class="form-control" id="city" name="city" value="{{ old('city', $location->city ?? null) }}" placeholder="" required/>
								</div>
							</div>
		<div class="col-sm-12 col-md-4">
    <div class="mb-3">
        <label for="display_name" class="control-label col-form-label">State</label>
        <select class="form-select me-sm-2" id="state_id" name="state_name" required>
            <option selected disabled value="">Select State...</option>
            <option value="California" {{ ($location->state_name ?? null) == 'California' ? 'selected' : '' }}>California</option>
            <option value="Texas" {{ ($location->state_name ?? null) == 'Texas' ? 'selected' : '' }}>Texas</option>
            <option value="Florida" {{ ($location->state_name ?? null) == 'Florida' ? 'selected' : '' }}>Florida</option>
            <option value="New York" {{ ($location->state_name ?? null) == 'New York' ? 'selected' : '' }}>New York</option>
            <option value="Illinois" {{ ($location->state_name ?? null) == 'Illinois' ? 'selected' : '' }}>Illinois</option>
            <option value="Pennsylvania" {{ ($location->state_name ?? null) == 'Pennsylvania' ? 'selected' : '' }}>Pennsylvania</option>
            <option value="Ohio" {{ ($location->state_name ?? null) == 'Ohio' ? 'selected' : '' }}>Ohio</option>
            <option value="Georgia" {{ ($location->state_name ?? null) == 'Georgia' ? 'selected' : '' }}>Georgia</option>
            <option value="North Carolina" {{ ($location->state_name ?? null) == 'North Carolina' ? 'selected' : '' }}>North Carolina</option>
            <option value="Michigan" {{ ($location->state_name ?? null) == 'Michigan' ? 'selected' : '' }}>Michigan</option>
        </select>
    </div>
</div>

							<div class="col-sm-12 col-md-4">
								<div class="mb-3">
								<label for="zip_code" class="control-label col-form-label" >Zip</label >
								<input type="text" class="form-control" id="zip_code" name="zip_code" value="{{ old('zip_code', $location->zipcode ?? null) }}" placeholder="" required/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12 col-md-12">
							</div>
						</div>
					</div>
			
				</div>
			</div>
			
		<div class="col-lg-3 d-flex align-items-stretch">
				<div class="card w-100">
					<div class="card-body border-top">
						<h4 class="card-title mb-3">&nbsp;</h4>
						<div class="row">
  							<div class="col-sm-12 col-md-12">
								<div class="mb-3">
 									<div class="form-group">
										<label for="lead_source" class="control-label col-form-label" >Customer Bills to</label >
										<input type="search" class="form-control" value="search customer...">
									</div>
								</div>
 							</div>
					<div class="col-sm-12 col-md-12">
    <div class="mb-3">
        <label for="lead_source" class="control-label col-form-label">Lead Source</label>
        <select class="form-select me-sm-2" id="lead_source" name="lead_source">
            <option value="">Select Lead Source</option>
            <option value="First American" {{ ($source->source_name ?? null) == 'First American' ? 'selected' : '' }}>First American</option>
            <option value="Google Local Service" {{ ($source->source_name ?? null) == 'Google Local Service' ? 'selected' : '' }}>Google Local Service</option>
            <option value="Hippo" {{ ($source->source_name ?? null) == 'Hippo' ? 'selected' : '' }}>Hippo</option>
            <option value="Yelp" {{ ($source->source_name ?? null) == 'Yelp' ? 'selected' : '' }}>Yelp</option>
        </select>
    </div>
</div>

						</div>
 					</div>
				</div>
			</div>

		</div>
		<!-- End row -->
		
		<!-- row -->
		<div class="row">
		
			<div class="col-lg-9 d-flex align-items-stretch">
				<div class="card w-100">
			

					<div class="card-body border-top">
						<h4 class="card-title">Notes</h4>
						<div class="row">
							<div class="col-sm-12 col-md-12">
								<div class="mb-3">
								  <label class="control-label col-form-label">Customer Notes</label>
 								  <input type="text" class="form-control" id="customer_notes" name="customer_notes" value="{{ old('customer_notes', $Note->note ?? null) }}" placeholder="" />
								</div>
 							</div>
 						</div>
						<div class="row">
							<div class="col-sm-12 col-md-12">
								<div class="mb-3">
								<label for="customer_tags" class="control-label col-form-label" >Customer Tags</label >
								<input type="text" class="form-control" id="customer_tags" name="customer_tags" value="{{ old('customer_tags', $tag->tag_name ?? null) }}" placeholder="" />
								</div>
							</div>
 						</div>
 					</div>
				
				</div>
			</div>
			
			
		</div>
		<!-- End row -->
		
		<!-- row -->
		<div class="row">
			<div class="p-3 border-top">
				<div class="action-form">
					<div class="mb-3 mb-0 text-center">
					<button type="submit" class="btn btn-info rounded-pill px-4 waves-effect waves-light">Save</button>
					<button type="submit" class="btn btn-dark rounded-pill px-4 waves-effect waves-light">Cancel</button>
					</div>
				</div>
			</div>
 		</div>


		<!-- End row -->
		
 
           
          
          <!-- -------------------------------------------------------------- -->
          <!-- End PAge Content -->
          <!-- -------------------------------------------------------------- -->
        </div>
        <!-- -------------------------------------------------------------- -->
        <!-- End Container fluid  -->
		
    </div>
</div>
	</form>

@endsection