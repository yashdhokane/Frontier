@extends('home')
@section('content')

	<form action="{{ route('technicians.store') }}" method="POST" enctype="multipart/form-data">
		@csrf		
 <!-- End Left Sidebar - style you can find in sidebar.scss  -->
      <!-- -------------------------------------------------------------- -->
      <!-- -------------------------------------------------------------- -->
      <!-- Page wrapper  -->
      <!-- -------------------------------------------------------------- -->
      <div class="page-wrapper" style="display:inline;">
        <!-- -------------------------------------------------------------- -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- -------------------------------------------------------------- -->
        <div class="page-breadcrumb">
          <div class="row">
            <div class="col-5 align-self-center">
              <h4 class="page-title">NEW TECHNICIAN</h4>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="customer-list.html">Technicians</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add New </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div class="col-7 align-self-center">
              <div class="d-flex no-block justify-content-end align-items-center">
                <div class="me-2">
                  <div class="lastmonth"></div>
                </div>
                <div class="">
                  <small>LAST MONTH</small>
                  <h4 class="text-info mb-0 font-medium">$58,256</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- -------------------------------------------------------------- -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- -------------------------------------------------------------- -->
        <style>
        .custom-alert {
    width: 98%; /* Adjust the width as needed */
    margin: 0 auto; /* Center the alert horizontally */
}
        </style>
		<div class="custom-alert">
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
</div>


</div>
@if(Session::has('success'))
    <div class="alert alert-success">
        {{ Session::get('success') }}
    </div>
@endif		<!-- Container fluid  -->
        <!-- -------------------------------------------------------------- -->
        <div class="container-fluid">
          <!-- -------------------------------------------------------------- -->
          <!-- Start Page Content -->
          <!-- -------------------------------------------------------------- -->
		   
 				
			<!-- row -->

			<div class="row">
			
				<div class="col-lg-6 d-flex align-items-stretch">
 					<div class="card w-100">
      								
		  					<div class="card-body border-top">
							<h4 class="card-title">Contact Info</h4>
							<div class="row">
								<div class="col-sm-12 col-md-6">
								<div class="mb-3">
								<label for="first_name" class="control-label col-form-label" >First Name</label >
								<input type="text" class="form-control" id="first_name" name="first_name" placeholder="" required/>
					
              
              	</div>
								</div>
								<div class="col-sm-12 col-md-6">
								<div class="mb-3">
								<label for="last_name" class="control-label col-form-label" >Last Name</label >
								<input type="text" class="form-control" id="last_name" name="last_name" placeholder="" required/>
								</div>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
									<label for="display_name" class="control-label col-form-label" >Display Name (shown on invoice)</label >
									<input type="text" class="form-control" id="display_name" name="display_name" placeholder="" required/>
									</div>
								</div>
 							</div>
							<div class="row">
								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
									<label for="email" class="control-label col-form-label" >Email</label >
									<input type="email" class="form-control" id="email" name="email" placeholder="" required/>
									</div>
								</div>
 							</div>
						<div class="row">
    						<div class="col-sm-12 col-md-12">
      						  <div class="mb-3">
        					      <label for="image" class="control-label col-form-label">Image Upload</label>
         					       <input type="file" class="form-control" id="image" name="image" accept="image/*"/>
   	     					  </div>
   							</div>
							</div>
						</div>
					
					</div>
				</div>
				
				<div class="col-lg-3 d-flex align-items-stretch">
 					<div class="card w-100">
						<div class="card-body border-top">
							<h4 class="card-title mb-3">&nbsp;</h4>
							<div class="row">
 								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="mobile_phone" class="control-label col-form-label" >Mobile Phone</label >
										<input type="text" class="form-control" id="mobile_phone" name="mobile_phone" placeholder="" required/>
									</div>
								</div>
							</div>
							<div class="row">
 								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="home_phone" class="control-label col-form-label" >Home Phone</label >
										<input type="text" class="form-control" id="home_phone" name="home_phone" placeholder="" />
									</div>
								</div>
							</div>
							<div class="row">
 								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="work_phone" class="control-label col-form-label" >Work Phone</label >
										<input type="text" class="form-control" id="work_phone" name="work_phone" placeholder="" />
									</div>
								</div>
							</div>
						</div>
					</div>
 				</div>
				
				<div class="col-lg-3 d-flex align-items-stretch">
 					<div class="card w-100">
						<div class="card-body border-top">
							<h4 class="card-title mb-3">&nbsp;</h4>
							<div class="row">
								<div class="row">
							<div class="col-sm-12 col-md-12">
								<div class="mb-3">
								<label for="user_tags" class="control-label col-form-label" >User Tags</label >
								<input type="text" class="form-control" id="user_tags" name="user_tags" placeholder="" />
								</div>
							</div>
 						</div>
							</div>
							<div class="row"  style="display:none;">
								<div class="col-sm-12 col-md-12">
									<div class="mb-3">
										<label for="role" class="control-label col-form-label" >Role</label >
										<input type="text" class="form-control" id="role" name="role" placeholder="" value="technician" />
									</div>
								</div>
							</div>
							
						</div>
					</div>
 				</div>
			
          </div>
          <!-- End row -->
		  
		  
		<!-- row -->
		<div class="row">
		
			<div class="col-lg-9 d-flex align-items-stretch">
				<div class="card w-100">
			
					<div class="card-body border-top">
						<h4 class="card-title">Address</h4>
						<div class="row">
							<div class="col-sm-12 col-md-9">
							<div class="mb-3">
							<label for="address1" class="control-label col-form-label" >Address Line 1 (Street)</label >
							<input type="text" class="form-control" id="address1" name="address1" placeholder="" required/>
							</div>
							</div>
							<div class="col-sm-12 col-md-3">
							<div class="mb-3">
							<label for="address_unit" class="control-label col-form-label" >Unit</label >
							<input type="text" class="form-control" id="address_unit" name="address_unit" placeholder="" />
							</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12 col-md-4">
								<div class="mb-3">
								<label for="city" class="control-label col-form-label" >City</label >
								<input type="text" class="form-control" id="city" name="city" placeholder="" required/>
								</div>
							</div>
							<div class="col-sm-12 col-md-4">
								<div class="mb-3">
									<label for="display_name" class="control-label col-form-label" >State</label >
									<select class="form-select me-sm-2" id="state_id" name="state_name" required>
    								<option selected disabled value="">Select State...</option>
   								 <option value="California">California</option>
   								 <option value="Texas">Texas</option>
   								 <option value="Florida">Florida</option>
   								 <option value="New York">New York</option>
   								 <option value="Illinois">Illinois</option>
   								 <option value="Pennsylvania">Pennsylvania</option>
   								 <option value="Ohio">Ohio</option>
   								 <option value="Georgia">Georgia</option>
   								 <option value="North Carolina">North Carolina</option>
   								 <option value="Michigan">Michigan</option>
								</select>

								</div>
							</div>
							<div class="col-sm-12 col-md-4">
								<div class="mb-3">
								<label for="zip_code" class="control-label col-form-label" >Zip</label >
								<input type="text" class="form-control" id="zip_code" name="zip_code" placeholder="" required/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12 col-md-12">
							</div>
						</div>
					</div>
			
				</div>
			</div>
			
		{{--	<div class="col-lg-3 d-flex align-items-stretch">
				<div class="card w-100">
					<div class="card-body border-top">
						<h4 class="card-title mb-3">&nbsp;</h4>
						<div class="row">
							<div class="col-sm-12 col-md-12">
								<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6991603.699017098!2d-100.0768425!3d31.168910300000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864070360b823249%3A0x16eb1c8f1808de3c!2sTexas%2C%20USA!5e0!3m2!1sen!2sin!4v1701086703789!5m2!1sen!2sin" width="100%" height="auto" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
							</div>
						</div>
					</div>
				</div>
			</div>
			--}}

		</div>
		<!-- End row -->
		
		<!-- row -->
	
		<!-- End row -->
		
		<!-- row -->
		<div class="row">
			<div class="p-3 border-top">
				<div class="action-form">
					<div class="mb-3 mb-0 text-center">
					<button type="submit" class="btn btn-info rounded-pill px-4 waves-effect waves-light">Save</button>
					<button type="submit" class="btn btn-dark rounded-pill px-4 waves-effect waves-light">Cancel</button>
					</div>
				</div>
			</div>
 		</div>


		<!-- End row -->
		
 
           
          
          <!-- -------------------------------------------------------------- -->
          <!-- End PAge Content -->
          <!-- -------------------------------------------------------------- -->
        </div>
        <!-- -------------------------------------------------------------- -->
        <!-- End Container fluid  -->
		
    </div>
</div>
	</form>

@endsection