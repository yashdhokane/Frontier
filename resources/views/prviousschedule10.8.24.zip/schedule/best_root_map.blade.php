<a href="#" data-id="{{$item->id}}" class="popup-option" onclick="openModal(this)">
    <i class="fa fa-map pe-2"></i> Best Route
</a>

<!--<script>
    function openModal(element) {
        var userId = element.getAttribute('data-id');
        console.log('User ID:', userId);

        var modal = new bootstrap.Modal(document.getElementById('mapModal'));
        modal.show();

        // Fetch the location data
        $.ajax({
            url: "{{ route('getLocation.bestroot') }}", // Replace with your Laravel route
            type: 'GET',
            data: { id: userId },
            success: function(response) {
                if (response.technician_location && response.sorted_customers) {
                     console.log('Technician Location:', response.technician_location);
                     console.log('Customer Locations:', response.sorted_customers);

                    // Display route on map
                    initMap(response.technician_location, response.sorted_customers);
                } else {
                    alert('Location data not found.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching location:', error);
            }
        });
    }

    // Initialize Google Map with route and blue color for the best route
    function initMap(technicianLocation, customerLocations) {
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 10,
            center: { lat: parseFloat(technicianLocation.latitude), lng: parseFloat(technicianLocation.longitude) },
        });

        var directionsService = new google.maps.DirectionsService();
        var directionsRenderer = new google.maps.DirectionsRenderer({
            polylineOptions: {
                strokeColor: 'blue',  // Set the road map color to blue
                strokeWeight: 6
            }
        });
        directionsRenderer.setMap(map);

        var waypoints = customerLocations.map(function(customer) {
            return {
                location: new google.maps.LatLng(parseFloat(customer.latitude), parseFloat(customer.longitude)),
                stopover: true
            };
        });

        var request = {
            origin: new google.maps.LatLng(parseFloat(technicianLocation.latitude), parseFloat(technicianLocation.longitude)),
            destination: waypoints[waypoints.length - 1].location,  // The last customer as the destination
            waypoints: waypoints.slice(0, -1),  // All customers except the last one as waypoints
            travelMode: google.maps.TravelMode.DRIVING
        };

        directionsService.route(request, function(result, status) {
            if (status === 'OK') {
                directionsRenderer.setDirections(result);

                // Create a colorful 3D man icon for the starting point
                var startingMarker = new google.maps.Marker({
                    position: { lat: parseFloat(technicianLocation.latitude), lng: parseFloat(technicianLocation.longitude) },
                    map: map,
                    icon: {
                        url: "https://img.icons8.com/3d/50/FF6347/human.png", // Colorful 3D man icon
                        scaledSize: new google.maps.Size(50, 50) // Adjust size as needed
                    }
                });

                // Iterate through the legs of the route to calculate distances and durations
                var legs = result.routes[0].legs;
                for (var i = 0; i < legs.length; i++) {
                    var leg = legs[i];
                    var infowindow = new google.maps.InfoWindow();

                    // Create a marker for the customer location
                    var customerLatLng = new google.maps.LatLng(parseFloat(leg.end_location.lat()), parseFloat(leg.end_location.lng()));
                    var marker = new google.maps.Marker({
                        position: customerLatLng,
                        map: map,
                        icon: {
                            url: "https://img.icons8.com/color/48/FFD700/pin.png", // Custom pin icon
                            scaledSize: new google.maps.Size(30, 30)
                        }
                    });

                    // Calculate distance and duration to the next stop
                    if (i < legs.length - 1) {
                        var nextLeg = legs[i + 1];
                        var distance = leg.distance.text; // Distance to next customer
                        var duration = leg.duration.text; // Duration to next customer

                        // Place a small circle between the two stops
                        var circle = new google.maps.Circle({
                            strokeColor: '#FF0000',
                            strokeOpacity: 0.8,
                            strokeWeight: 2,
                            fillColor: '#FF0000',
                            fillOpacity: 0.35,
                            map: map,
                            center: customerLatLng,
                            radius: 100 // Small circle radius
                        });

                        // Add a click listener to show distance and duration
                        google.maps.event.addListener(circle, 'click', (function(distance, duration) {
                            return function() {
                                infowindow.setContent(`Distance: ${distance}<br>Duration: ${duration}`);
                                infowindow.setPosition(circle.getCenter());
                                infowindow.open(map);
                            };
                        })(distance, duration));
                        
                        // Add blinking effect to the markers
                        blinkMarker(marker);
                    }
                }
            } else {
                console.error('Directions request failed due to ' + status);
            }
        });
    }

    // Function to create a blinking effect on the markers
    function blinkMarker(marker) {
        setInterval(function() {
            marker.setMap(marker.getMap() ? null : map);
        }, 1000); // Blink every second
    }
</script>

 -->
 <script>
    function openModal(element) {
        var userId = element.getAttribute('data-id');
        console.log('User ID:', userId);

        var modal = new bootstrap.Modal(document.getElementById('mapModal'));
        modal.show();

        // Fetch the location data
        $.ajax({
            url: "{{ route('getLocation.bestroot') }}", // Replace with your Laravel route
            type: 'GET',
            data: { id: userId },
            success: function(response) {
                if (response.technician_location && response.sorted_customers) {
                    console.log('Technician Location:', response.technician_location);
                    console.log('Customer Locations:', response.sorted_customers);

                    // Display route on map
                    initMap(response.technician_location, response.sorted_customers);
                } else {
                    alert('Location data not found.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching location:', error);
            }
        });
    }
// Initialize Google Map with route and blue color for the best route
function initMap(technicianLocation, customerLocations) {
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 10,
        center: { lat: parseFloat(technicianLocation.latitude), lng: parseFloat(technicianLocation.longitude) },
    });

    var directionsService = new google.maps.DirectionsService();
    var directionsRenderer = new google.maps.DirectionsRenderer({
        polylineOptions: {
            strokeColor: 'blue',  // Set the road map color to blue
            strokeWeight: 6,
             suppressMarkers: false,
             position:false,
             marker:false 
        }
    });
    directionsRenderer.setMap(map);

    var waypoints = customerLocations.map(function(customer) {
        return {
            location: new google.maps.LatLng(parseFloat(customer.latitude), parseFloat(customer.longitude)),
            stopover: false
         
        };
    });

    var request = {
        origin: new google.maps.LatLng(parseFloat(technicianLocation.latitude), parseFloat(technicianLocation.longitude)),
        destination: waypoints[waypoints.length - 1].location,  // The last customer as the destination
         waypoints: waypoints.slice(0, -1),  // All customers except the last one as waypoints
        travelMode: google.maps.TravelMode.DRIVING
    };

    directionsService.route(request, function(result, status) {
        if (status === 'OK') {
            directionsRenderer.setDirections(result);

            // Create marker for the technician
            var technicianPosition = {
                lat: parseFloat(technicianLocation.latitude),
                lng: parseFloat(technicianLocation.longitude)
            };
            createMarker(technicianPosition, technicianLocation.name, map, false);

            // Create customer markers
            for (var i = 0; i < customerLocations.length; i++) {
                var customer = customerLocations[i]; // Get the customer data
                var customerPosition = {
                    lat: parseFloat(customer.latitude),
                    lng: parseFloat(customer.longitude)
                };
               createMarker(customerPosition, customer.name, map, false);
            }
        } else {
            console.error('Directions request failed due to ' + status);
        }
    });
}

// Function to create a marker and its info window
function createMarker(position, name, map, isTechnician) {
    var marker = new google.maps.Marker({
        position: position,
        map: map, // Keep the map property to ensure the marker is displayed
        icon: {
            url: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png', // Red marker for technician and customers
            scaledSize: new google.maps.Size(isTechnician ? 60 : 50, isTechnician ? 60 : 50)
        }
    });

    // Geocode the position to get the address
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({ location: position }, function(results, status) {
        if (status === 'OK' && results[0]) {
            var address = results[0].formatted_address; // Get the formatted address
            var content = `<div style="color: black; background-color: white; padding: 5px; border-radius: 3px;">
                                ${name}<br>
                               ${address}
                           </div>`;
            var infoWindow = new google.maps.InfoWindow({
                content: content
            });

            marker.addListener('click', function() {
                infoWindow.open(map, marker);
            });
        } else {
            console.error('Geocoder failed due to: ' + status);
        }
    });
}



</script>



<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCa7BOoeXVgXX8HK_rN_VohVA7l9nX0SHo"></script>
