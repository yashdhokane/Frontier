<!DOCTYPE html>
<html>
<head>
    <title>Notification</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; padding: 0;">

    <p>{{ $mailData['message'] ?? 'No message provided.' }}</p>

    <p>Best regards,<br>Your Scheduling Team</p>
</body>
</html>
