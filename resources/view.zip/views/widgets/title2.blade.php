<iframe src="{{ route('google1.search') }}" style="width: 100%; height: 400px; border: none;" id="assetsIframe"></iframe>
