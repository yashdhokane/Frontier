{{-- <div class="col-md-4 col-sm-12 d-flex align-items-stretch grid-item box" tabindex="0" data-index="0">
    <div class="card w-100">
        <div class="card-body card-border shadow">
            <div class="form-group">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-warning">Customers</h4>
                    <button type="button" class="btn btn-link text-warning expand-toggle" data-index="0">Expand</button>
                </div> --}}
<!-- Add iframe or other content here -->

<iframe src="https://dispatchannel.com/portal/customers-iframe?header=off&sidebar=off"
    style="width: 100%;  height: 400px; border: none;" id="customerIframe">
</iframe>
{{-- </div>
        </div>
    </div>
</div> --}}
