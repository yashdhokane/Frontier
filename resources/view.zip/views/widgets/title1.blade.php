
<!-- Add iframe for Google here 
<script async src="https://cse.google.com/cse.js?cx=929815ee2d1cd4079"></script>
 <div class="gcse-search" data-linktarget="_self"></div>    

 <script async src="https://cse.google.com/cse.js?cx=929815ee2d1cd4079"></script>
<iframe src="about:blank" style="width: 100%; height: 400px; border: none;" id="assetsIframe">
    <div class="gcse-search" data-linktarget="_self"></div>
</iframe>  -->


<iframe src="{{ route('google.search') }}" style="width: 100%; height: 400px; border: none;" id="assetsIframe"></iframe>

