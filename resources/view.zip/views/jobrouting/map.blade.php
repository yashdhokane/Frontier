<div class="col-md-9" id="mapdiv">
    <div id="map" class="full-width-map card card-shadow"></div>
</div>