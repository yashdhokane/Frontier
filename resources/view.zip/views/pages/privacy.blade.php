@extends('home')
@section('content')
    <div class="page-breadcrumb">		
		<div class="row">			
			<div class="col-5 align-self-center">				
				<h4 class="page-title">Privacy Policy - Dispatch Channel Inc.!</h4>				
				<div class="d-flex align-items-center">
				</div>			
			</div>		
		</div>	
	</div>
	
    <div class="container-fluid">
		<div class="row">				   <div class="col-lg-9">						    <div class="card">                    <div class="card-body card-border shadow">
					  <div class="col-12">
						<h4 class="card-title uppercase">Privacy Policy</h4>
						<p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam.</p>

						<h5 class="card-title uppercase mt-4">Information Collection</h5>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
						
						<h5 class="card-title uppercase mt-4">Use of Information</h5>
						<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						
						<h5 class="card-title uppercase mt-4">Data Protection</h5>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
						
						<h5 class="card-title uppercase mt-4">Cookies</h5>
						<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
						
						<h5 class="card-title uppercase mt-4">Third-Party Services</h5>
						<p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
						
						<h5 class="card-title uppercase mt-4">Changes to This Policy</h5>
						<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur?</p>
						
						<h5 class="card-title uppercase mt-4">Contact Us</h5>
						<p>Quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur?</p>
					  </div>
					</div>				</div>		    </div>						
					
				<div class="col-lg-3">
				@include('pages.nav')
				</div>
					
		</div>
		
  </div>


@section('script')
@endsection
@endsection
