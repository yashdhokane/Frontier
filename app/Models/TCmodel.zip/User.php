<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'image',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];


    public function roles(){
        return $this->belongsToMany(Role::class);
    }

    public function isAdmin()
    {
        return $this->hasRole('admin');
    }
    
    public function tickets()
    {
        return $this->hasMany(Ticket::class);
    }

     public function Location()
    {
        return $this->hasOne(CustomerUserAddress::class, 'user_id', 'id');
    }
	// User.php (assuming this is your User model)




  public function tag()
    {
        return $this->hasOne(UserTagIdCategory::class, 'user_id', 'id');
    }
    
	 public function meta()
    {
        return $this->hasOne(CustomerUserMeta::class, 'user_id', 'id');
    }
    
     public function leadsourcename()
    {
        return $this->hasOne(Leadsource::class, 'user_id', 'id');
    }

     public function Note()
    {
        return $this->hasOne(UserNotesCustomer::class, 'user_id', 'id');
    }
    

}
