<?php

namespace App\Http\Controllers;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;


use App\Models\Role;
use App\Models\User;
use App\Models\CustomerUserMeta;
use Illuminate\Http\Request;
use App\Models\CustomerUserAddress;
use App\Models\UserTagIdCategory;
use App\Models\UserLeadSourceCustomer;

use App\Models\UserNotesCustomer;





class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $users = User::where('role', 'customer')->get();
        // $users = User::all();
 
        return view('users.index', ['users'=>$users]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
       $users = User::all();
               $roles = Role::all();

       return view('users.create', ['user'=>$users,'roles'=>$roles]);
    }

    /**
     * Store a newly created resource in storage.
     */
   public function store(Request $request)
{
  // dd($request->all());
    // Validate the request
    $validator = Validator::make($request->all(), [
    
    'first_name' => 'required|max:255',
    'last_name' => 'required|max:255',
    'display_name' => 'required|string|max:255',
    'email' => 'required|email|unique:users,email',
    'mobile_phone' => 'required|max:20', 
    // 'home_phone' => 'required|max:20', 
    // 'work_phone' => 'required|max:20', 
  
 
    'address1' => 'required',
	// 'address_unit' => 'required',
    
    'city' => 'required',
    'state_name' => 'required',
    'zip_code' => 'max:10',
    // 'customer_notes' => 'required',
    // 'customer_tags' => 'required', // Update the maximum length as needed
    // 'lead_source' => 'required',
	// 'image' => 'required',
	// 'user_type' => 'required',
	// 'company' => 'required',
	// 'role' => 'required',
]);

if ($validator->fails()) {
    return redirect()
        ->back()
        ->withErrors($validator)
        ->withInput();
}

    // If validation passes, create the user and related records
    $user = new User();
    $user->name = $request['display_name'];
    $user->email = $request['email'];
    $user->mobile = $request['mobile_phone'];
	$user->company = $request['company'];
	$user->user_type = $request['user_type'];
	$user->position = $request['role'];

	if ($request->hasFile('image')) 
	{
    $image = $request->file('image');
    $imageName = time() . '_' . $image->getClientOriginalName();
	$image->move(public_path('images'), $imageName);
	$user->user_image = $imageName;
	}
    $user->save();

    $userId = $user->id;
    $currentTimestamp = now();

    $userMeta = [
        ['user_id' => $userId, 'meta_key' => 'first_name', 'meta_value' => $request['first_name']],
        ['user_id' => $userId, 'meta_key' => 'last_name', 'meta_value' => $request['last_name']],
        ['user_id' => $userId, 'meta_key' => 'home_phone', 'meta_value' => $request['home_phone']],
        ['user_id' => $userId, 'meta_key' => 'work_phone', 'meta_value' => $request['work_phone']],
        ['user_id' => $userId, 'meta_key' => 'created_at', 'meta_value' => $currentTimestamp],
        ['user_id' => $userId, 'meta_key' => 'updated_at', 'meta_value' => $currentTimestamp],
    ];

    CustomerUserMeta::insert($userMeta);

    $customerAddress = new CustomerUserAddress();
    $customerAddress->user_id = $userId; 
    $customerAddress->address_line1 = $request['address1'];
	$customerAddress->address_line2 = $request['address_unit'];
	$customerAddress->city = $request['city'];
    $customerAddress->state_name = $request['state_name'];
    $customerAddress->zipcode = $request['zip_code'];
    $customerAddress->save();

    $userNotes = new UserNotesCustomer();
    $userNotes->user_id = $userId; 
    $userNotes->note = $request['customer_notes'];
    $userNotes->save();

    $userTags = new UserTagIdCategory();
    $userTags->user_id = $userId; 
    $userTags->tag_name= $request['customer_tags'];
    $userTags->save();

    $userLeadSource = new UserLeadSourceCustomer();
    $userLeadSource->user_id = $userId; 
    $userLeadSource->source_name = $request['lead_source'];
    $userLeadSource->save();
    // dd("end");
    return redirect()->route('users.index')->with('success', 'User created successfully');
}
    
    

     public function show(string $id)
    {
		  $roles = Role::all();
        $user = User::find($id);
		 $meta = $user->meta;
    $home_phone = $user->meta()->where('meta_key', 'home_phone')->value('meta_value') ?? '';
      
        return view('users.show', compact('user','roles','home_phone'));
    }
    
    /**
     * Show the form for editing the specified resource.
     */
  public function edit($id)
{
    $user = User::find($id);
    $meta = $user->meta;
	  $first_name = $user->meta()->where('meta_key', 'first_name')->value('meta_value') ?? '';
    $last_name = $user->meta()->where('meta_key', 'last_name')->value('meta_value') ?? '';
    $home_phone = $user->meta()->where('meta_key', 'home_phone')->value('meta_value') ?? '';
    $work_phone = $user->meta()->where('meta_key', 'work_phone')->value('meta_value') ?? '';

     
	$location = $user->location;
    $Note = $user->Note;
    $tag = $user->tag;
    $source = $user->source;

    return view('users.edit', compact('user', 'meta', 'location', 'Note', 'tag', 'source','first_name','last_name','home_phone','work_phone'));
}

    /**
     * Update the specified resource in storage.
     */
  public function update(Request $request, $id)
{
    // Validate the request
    $validator = Validator::make($request->all(), [
        'first_name' => 'required|max:255',
        'last_name' => 'required|max:255',
        'display_name' => 'required|string|max:255',
        'email' => 'required|email|unique:users,email,' . $id,
        'mobile_phone' => 'required|max:20',
        'address1' => 'required',
        'city' => 'required',
        'state_name' => 'required',
        'zip_code' => 'max:10',
    ]);

    if ($validator->fails()) {
        return redirect()
            ->back()
            ->withErrors($validator)
            ->withInput();
    }

    // Find the user by ID
    $user = User::findOrFail($id);

    // Update user data
    $user->name = $request['display_name'];
    $user->email = $request['email'];
    $user->mobile = $request['mobile_phone'];
    $user->company = $request['company'];
    $user->user_type = $request['user_type'];
    $user->position = $request['role'];

    // Check if a new image file is provided
    if ($request->hasFile('image')) {
        $image = $request->file('image');
        $imageName = time() . '_' . $image->getClientOriginalName();
        $image->move(public_path('images'), $imageName);
        $user->user_image = $imageName;
    }

    $user->save();

    // Update user metadata
    CustomerUserMeta::where('user_id', $id)->where('meta_key', 'first_name')->update([
        'meta_value' => $request['first_name'],
    ]);

    CustomerUserMeta::where('user_id', $id)->where('meta_key', 'last_name')->update([
        'meta_value' => $request['last_name'],
    ]);

    CustomerUserMeta::where('user_id', $id)->where('meta_key', 'home_phone')->update([
        'meta_value' => $request['home_phone'],
    ]);

    CustomerUserMeta::where('user_id', $id)->where('meta_key', 'work_phone')->update([
        'meta_value' => $request['work_phone'],
    ]);

    // Repeat the above lines for other metadata fields as needed

    // Update user address
    CustomerUserAddress::where('user_id', $id)->update([
        'address_line1' => $request['address1'],
        'address_line2' => $request['address_unit'],
        'city' => $request['city'],
        'state_name' => $request['state_name'],
        'zipcode' => $request['zip_code'],
    ]);

    // Update user notes
    UserNotesCustomer::where('user_id', $id)->update([
        'note' => $request['customer_notes'],
    ]);

    // Update user tags
 $userTag = UserTagIdCategory::where('user_id', $id)->first();

    if ($userTag) {
        $userTag->update(['tag_name' => $request['customer_tags']]);
    } else {
        UserTagIdCategory::create([
            'user_id' => $id,
            'tag_name' => $request['customer_tags'],
            'created_by' => auth()->user()->id,
        ]);
    }


    // Update user lead source
    UserLeadSourceCustomer::where('user_id', $id)->update([
        'source_name' => $request['lead_source'],
    ]);

    return redirect()->route('users.index')->with('success', 'User updated successfully');
}


    /**
     * Remove the specified resource from storage.
     */
     
public function destroy($id)
{
    try {
        $user = User::findOrFail($id);

        // Delete related records
        CustomerUserMeta::where('user_id', $id)->delete();
        CustomerUserAddress::where('user_id', $id)->delete();
        UserNotesCustomer::where('user_id', $id)->delete();
        UserTagIdCategory::where('user_id', $id)->delete();
        UserLeadSourceCustomer::where('user_id', $id)->delete();

        // Delete the user's image if it exists and a new image is not being uploaded
        if (empty(request()->file('image')) && !empty($user->user_image)) {
            $imagePath = public_path('images') . '/' . $user->user_image;
            if (File::exists($imagePath)) {
                File::delete($imagePath);
            }
        }

        $user->delete();

        return redirect()->route('users.index')->with('success', 'User deleted successfully');
    } catch (\Exception $e) {
        return redirect()->route('users.index')->with('error', 'Failed to delete user');
    }
}

    // Show tickets assigned to a specific user
    public function showUserTickets($userId)
    {
        $user = User::findOrFail($userId);
        $tickets = $user->tickets;
        return view('users.tickets', ['user' => $user, 'tickets' => $tickets]);
    }

    // Assign a ticket to a user
    public function assignTicket(Request $request, $ticketId)
    {
        $ticket = Ticket::findOrFail($ticketId);
        
        // Assuming 'assigned_user_id' is the field to store the assigned user's ID in the ticket table
        $ticket->assigned_user_id = $request->input('user_id');
        $ticket->save();

        // Redirect or respond as needed
        return redirect()->route('tickets.show', $ticket->id);
    }
}
