<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use App\Models\CustomerUserMeta;
use Illuminate\Http\Request;
use App\Models\CustomerUserAddress;
use App\Models\UserTagIdCategory;
use App\Models\UserLeadSourceCustomer;
use App\Models\UserNotesCustomer;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use App\Models\Technician;
use App\Models\UserTagsTechnicians;
use Carbon\Carbon;

class TechnicianController extends Controller
{

   public function index()
{
    $users = User::where('role', 'technician')->get();
    
    return view('technicians.index', compact('users'));
}


    public function create()
    {
        $users = User::all();
            //    $roles = Role::all();

        
        return view('technicians.create', ['user'=>$users]);
    }

public function store(Request $request)
{
// dd($request->all());
    // Validate the request
    $validator = Validator::make($request->all(), [
    
    'first_name' => 'required|max:255',
    'last_name' => 'required|max:255',
    'display_name' => 'required|string|max:255',
    'email' => 'required|email|unique:users,email',
    'mobile_phone' => 'required|max:20', 
    // 'home_phone' => 'required|max:20', 
    // 'work_phone' => 'required|max:20', 
//    'role' => 'required',
 
    'address1' => 'required',
	// 'address_unit' => 'required',
    
    'city' => 'required',
    'state_name' => 'required',
    'zip_code' => 'max:10',
    
    // 'user_tags' => 'required', // Update the maximum length as needed
  
	// 'image' => 'required',


]);
if ($validator->fails()) {
    return redirect()
        ->back()
        ->withErrors($validator)
        ->withInput();
}

    // If validation passes, create the user and related records
    $user = new User();
    $user->name = $request['display_name'];
    $user->email = $request['email'];
    $user->mobile = $request['mobile_phone'];
    $user->role = $request['role'];


	if ($request->hasFile('image')) 
	{
    $image = $request->file('image');
    $imageName = time() . '_' . $image->getClientOriginalName();
	$image->move(public_path('images'), $imageName);
	$user->user_image = $imageName;
	}
    $user->save();

    $userId = $user->id;
    $currentTimestamp = now();

    $userMeta = [
        ['user_id' => $userId, 'meta_key' => 'first_name', 'meta_value' => $request['first_name']],
        ['user_id' => $userId, 'meta_key' => 'last_name', 'meta_value' => $request['last_name']],
        ['user_id' => $userId, 'meta_key' => 'home_phone', 'meta_value' => $request['home_phone']],
        ['user_id' => $userId, 'meta_key' => 'work_phone', 'meta_value' => $request['work_phone']],
        ['user_id' => $userId, 'meta_key' => 'created_at', 'meta_value' => $currentTimestamp],
        ['user_id' => $userId, 'meta_key' => 'updated_at', 'meta_value' => $currentTimestamp],
    ];

    CustomerUserMeta::insert($userMeta);

    $customerAddress = new CustomerUserAddress();
    $customerAddress->user_id = $userId; 
    $customerAddress->address_line1 = $request['address1'];
	$customerAddress->address_line2 = $request['address_unit'];
	$customerAddress->city = $request['city'];
    $customerAddress->state_name = $request['state_name'];
    $customerAddress->zipcode = $request['zip_code'];
    $customerAddress->save();


    $userTags = new UserTagIdCategory();
    $userTags->user_id = $userId; 
    $userTags->tag_name= $request['user_tags'];
    $userTags->save();

 
//    dd("end");
    return redirect()->route('technicians.index')->with('success', 'Technician created successfully');
}



    public function show($id)
    {
      
        $technician = User::find($id);
		 $meta = $technician->meta;
    $home_phone = $technician->meta()->where('meta_key', 'home_phone')->value('meta_value') ?? '';
        return view('technicians.show', compact('technician','home_phone'));
    }


public function edit(string $id)
{
    $technician = User::find($id);

    // Check if $user is found
    if (!$technician) {
        // Handle the case where the user is not found, perhaps redirect to an error page
        return redirect()->route('technicians.index');
    }

    // Check if $user has meta relationship
    $meta = $technician->meta;
    if ($meta) {
        $first_name = $technician->meta()->where('meta_key', 'first_name')->value('meta_value') ?? '';
        $last_name = $technician->meta()->where('meta_key', 'last_name')->value('meta_value') ?? '';
        $home_phone = $technician->meta()->where('meta_key', 'home_phone')->value('meta_value') ?? '';
        $work_phone = $technician->meta()->where('meta_key', 'work_phone')->value('meta_value') ?? '';

        $location = $technician->location;
        $Note = $technician->Note;
        $tag = $technician->tag;
        $source = $technician->source;

        return view('technicians.edit', compact('technician', 'meta', 'location', 'Note', 'tag', 'source', 'first_name', 'last_name', 'home_phone', 'work_phone'));
    } else {
        // Handle the case where meta is not found, perhaps redirect to an error page
        return redirect()->route('technicians.index');
    }
}
  public function update(Request $request, $id)
{
    // Validate the request
    $validator = Validator::make($request->all(), [
        'first_name' => 'required|max:255',
        'last_name' => 'required|max:255',
        'display_name' => 'required|string|max:255',
        'email' => 'required|email|unique:users,email,' . $id,
        'mobile_phone' => 'required|max:20',
        'address1' => 'required',
        'city' => 'required',
        'state_name' => 'required',
        'zip_code' => 'max:10',
    ]);

    if ($validator->fails()) {
        return redirect()
            ->back()
            ->withErrors($validator)
            ->withInput();
    }

    // Retrieve the existing user
    $user = User::find($id);

    // Check if the user is found
    if (!$user) {
        return redirect()->route('technicians.index')->with('error', 'User not found');
    }

    // Update user details
    $user->name = $request['display_name'];
    $user->email = $request['email'];
    $user->mobile = $request['mobile_phone'];
    $user->company = $request['company']; // Add any additional fields you need to update
    $user->role = $request['role'];

    // Update image if provided
    if ($request->hasFile('image')) {
        $image = $request->file('image');
        $imageName = time() . '_' . $image->getClientOriginalName();
        $image->move(public_path('images'), $imageName);
        $user->user_image = $imageName;
    }

    // Save the user record
    $user->save();

    // Update related records
    $user->meta()->updateOrCreate(
        ['meta_key' => 'first_name'],
        ['meta_value' => $request['first_name']]
    );

    $user->meta()->updateOrCreate(
        ['meta_key' => 'last_name'],
        ['meta_value' => $request['last_name']]
    );

    $user->meta()->updateOrCreate(
        ['meta_key' => 'home_phone'],
        ['meta_value' => $request['home_phone']]
    );

    $user->meta()->updateOrCreate(
        ['meta_key' => 'work_phone'],
        ['meta_value' => $request['work_phone']]
    );

    $user->Location()->update([
        'address_line1' => $request['address1'],
        'address_line2' => $request['address_unit'],
        'city' => $request['city'],
        'state_name' => $request['state_name'],
        'zipcode' => $request['zip_code'],
    ]);

    $user->tag()->update([
        'tag_name' => $request['user_tags'],
    ]);

    return redirect()->route('technicians.index')->with('success', 'Technician updated successfully');
}


public function destroy($id)
{
    // Find the user by ID
    $user = User::find($id);

    // Check if the user exists
    if (!$user) {
        return redirect()->route('technicians.index')->with('error', 'User not found');
    }

    // Delete associated records in CustomerUserMeta
    CustomerUserMeta::where('user_id', $id)->delete();

    // Delete associated records in CustomerUserAddress
    CustomerUserAddress::where('user_id', $id)->delete();

    // Delete associated records in UserTagIdCategory
    UserTagIdCategory::where('user_id', $id)->delete();

    // Delete the user's image file
    if ($user->user_image) {
        $imagePath = public_path('images') . '/' . $user->user_image;
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }

    // Delete the user
    $user->delete();

    return redirect()->route('technicians.index')->with('success', 'Technician deleted successfully');
}

 

 public function technicianGet()
    {
        $technicians = Technician::get();
        return view('technicians.technician_loactor', compact('technicians'));
    }


}
