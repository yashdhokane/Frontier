<a class="nav-link waves-effect waves-dark" href="javascript:void(0)"><i data-feather="search"
		class="feather-sm"></i></a>

<form class="app-search position-absolute">

	<input type="text" class="form-control" placeholder="Search &amp; enter" />

	<a class="srh-btn"><i data-feather="x" class="feather-sm"></i></a>

</form>