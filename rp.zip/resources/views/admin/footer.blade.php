<footer class="footer text-center">All Rights Reserved by Frontier Tech Services. </footer>
